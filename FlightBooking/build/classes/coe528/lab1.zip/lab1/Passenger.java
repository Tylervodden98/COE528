/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

/**
 *
 * @author vodde
 */
public abstract class Passenger {
    String name;
    int age;
    
    public Passenger(String n, int a)
    {
        this.name=n;
        this.age=a;
    }
    
    public String getName()
        {
            return name;
        }
        
        public void setName(String n)
        {
            this.name=n;
        }
        
        public int getAge()
        {
            return age;
        }
        
        public void setAge(int a)
        {
            this.age=a;
        }
      
    public abstract double applyDiscount(double p);
    
}
