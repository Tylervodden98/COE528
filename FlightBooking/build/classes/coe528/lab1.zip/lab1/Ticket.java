/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

/**
 *
 * @author tvodden
 */

public class Ticket {
    Passenger passenger;
    Flight flight;
    double price;
    static int ticketcount=0;
    
        public Ticket(Passenger p, Flight flight, double price)
        {
            this.passenger=p;
            this.flight=flight;
            this.price=price;
            ticketcount++;
        }
        
        @Override
        public String toString()
        {
            return("" + flight.getflightNum() + "," + flight.getOrigin() + " to " + flight.getDest() + "," + flight.getDepartTime() + ", original price:" + flight.getoriginalPrice() + "$, ticket price: $" + this.price );
        }
        
        public Passenger getPassenger()
        {
            return passenger;
        }
        
        public void setPassenger(Passenger n)
        {
            this.passenger=n;
        }
        
        public Flight getFlight()
        {
            return flight;
        }
        
        public void setFlight(Flight f)
        {
            this.flight=f;
        }
        
        public double getPrice()
        {
            return price;
        }
        
        public void setPrice(double p)
        {
            this.price=p;
        }
}

