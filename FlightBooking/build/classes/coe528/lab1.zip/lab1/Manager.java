/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

import java.util.LinkedList;



/**
 *
 * @author vodde
 */
public class Manager {
    Flight[] aircanada = new Flight[10];
    LinkedList<Ticket> tick;
            
    public Manager(){
        this.tick = new LinkedList<>();
    }
    
    public void createFlights(){
        
        aircanada[0]= new Flight(1004,"Montreal","Toronto","10:00",200,100.0);
        aircanada[1]= new Flight(1005,"Vancouver","Toronto","10:00",200,100.0);
        aircanada[2]= new Flight(1006,"Toronto","Montreal","10:00",200,100.0);
        aircanada[3]= new Flight(1007,"Toronto","Vancouver","10:00",200,100.0);
        aircanada[4]= new Flight(1008,"Montreal","Vancouver","10:00",200,100.0);
        aircanada[5]= new Flight(1009,"Ottawa","Winnipeg","10:00",200,100.0);
        aircanada[6]= new Flight(1010,"Montreal","Edmonton","10:00",200,100.0);
        aircanada[7]= new Flight(1011,"Calgary","Toronto","10:00",200,100.0);
        aircanada[8]= new Flight(1012,"Toronto","Montreal","10:00",2,1000.69);
        aircanada[9]= new Flight(1013,"Montreal","Toronto","10:00",200,500.0);
        
    }
    
    public void displayAvailableFlights(String origin, String destination){
       for (Flight flight :aircanada){
           {
               if(origin.equals(flight.getOrigin())&& destination.equals(flight.getDest()) && flight.getnumOfSeatsLeft()>0)
               {
                   System.out.println("Flights available:"+ flight.toString());
               }
           }    
       }
    }
    
    public Flight getFlight(int flightNumber){
        for (Flight flight : aircanada){
            if(flightNumber == flight.getflightNum()){
                return flight;
            }
        }
    return null;
    }
    
    public void bookSeat(int flightNumber, Passenger p){
        
        if(getFlight(flightNumber).bookASeat()){
            tick.add(new Ticket(p,getFlight(flightNumber),p.applyDiscount(getFlight(flightNumber).getoriginalPrice())));
            
            System.out.println(tick.get(tick.size()-1).getPassenger().getName() + " Booked flight:" + tick.get(tick.size()-1).toString());
        }
        else{
            System.out.println("Flight is full try booking another one.");
        }
    }
    
public static void main(String[] args){
   
Manager man = new Manager();
Passenger bob = new Member("bob",70,7);
Passenger joe = new Member("joe",50,2);
Passenger don = new NonMember("don",66);
Passenger ryan = new NonMember("ryan",10);

/*createFlights method*/
man.createFlights();
/*display flights from Toronto to Montreal*/
man.displayAvailableFlights("Toronto","Montreal");
/*display flights from Toronto to Montreal*/
man.displayAvailableFlights("Montreal","Toronto");
/*bob and ryan book seats*/
/*50 percent discount*/
man.bookSeat(1012,bob);
/*10 percent member discount*/
man.bookSeat(1012,joe);
/*10 percent nonmember discount*/
man.bookSeat(1006,don);
/*no discount*/
man.bookSeat(1006, ryan);

/*showing that no longer displays fully booked flight 1012*/
man.displayAvailableFlights("Toronto","Montreal");
}
}


