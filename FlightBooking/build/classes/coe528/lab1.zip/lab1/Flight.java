/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

import java.util.Objects;

/**
 *
 * @author vodde
 */
public class Flight {
        int flightNum;
        String origin;
        String dest;
        String departTime;
        int cap;
        int numOfSeatsLeft;
        double originalPrice;
        
        public Flight(int flightNum, String origin, String dest, String departTime, int cap, double originalPrice)
        {
            this.flightNum=flightNum;
            this.origin=origin;
            this.dest=dest;
            this.departTime=departTime;
            this.cap=cap;
            this.originalPrice=originalPrice;
            this.numOfSeatsLeft=cap;
            
            
            if(origin != null && origin.equals(dest))
            {
                throw new IllegalArgumentException("Origin cannot be the same as destination!!!");
            }  
        }
        @Override
        public String toString()
        {
            return("" + this.flightNum + "," + this.origin + " to " + this.dest + "," + this.departTime + ", original price:" + this.originalPrice + "$");
        }
        
        
        public int getflightNum()
        {
            return flightNum;
        }
        
        public void setflightNum(int n)
        {
            this.flightNum=n;
        }
        
        public String getOrigin()
        {
            return origin;
        }
        
        public void setOrigin(String s)
        {
            this.origin=s;
        }
        
        public String getDest()
        {
            return dest;
        }
        
        public void setDest(String d)
        {
            this.dest=d;
        }
        
        public String getDepartTime()
        {
            return departTime;
        }
        
        public void setDepartTime(String d)
        {
            this.departTime=d;
        }
        
        public int getCapacity()
        {
            return cap;
        }
        
        public void setCapacity(int n)
        {
            this.cap=n;
            this.numOfSeatsLeft=n;
        }
        
        public double getoriginalPrice()
        {
            return originalPrice;
        }
        
        public void setoriginalPrice(double n)
        {
            this.originalPrice=n;
        }
        
        public int getnumOfSeatsLeft()
        {
            return numOfSeatsLeft;
        }
        
        public boolean bookASeat()
        {
            if(numOfSeatsLeft>0)
            {
                numOfSeatsLeft--;
                return (true);
            }else
            {
                return (false);
            }
        }   
}
