/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

/**
 *
 * @author vodde
 */
public class Member extends Passenger{

    int yearsOfMembership;
    
    public Member(String n, int a, int y)
    {
        super(n,a);
        this.yearsOfMembership=y;
    }
    
    @Override
    public double applyDiscount(double p) {
        double x;
        if(yearsOfMembership > 5)
        {
            x=0.5*p;
            return x;
        }
        else if(yearsOfMembership>1 && yearsOfMembership <= 5)
        {
            x=0.9*p;
            return x;
        }
        else
        x=p;
        return x;
    }

    
}
