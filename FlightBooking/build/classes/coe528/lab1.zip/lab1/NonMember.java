/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

/**
 *
 * @author vodde
 */
public class NonMember extends Passenger{
  
    public NonMember(String n, int a)
    {
        super(n,a);
    }
    
    @Override
    public double applyDiscount(double p) {
        double x;
        if(getAge() > 65)
        {
            x=0.9*p;
            return x;
        }
        else
        {
            x=p;            
            return x;
        }
}
}